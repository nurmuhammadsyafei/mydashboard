<section class="content">

   <div class="row" >
       
      <div class="col-md-12">
         <div class="box box-warning">
            <div class="box-body ">
               <div class="box box-widget widget-user-2">
                  <div class="widget-user-header ">
                  <?= form_open( base_url('administrator/employee/get_add') ,['method' => 'POST']); ?>
                    <div class="row">
                      <div class="col-md-4">
                        <i>Cek Kode Yang Di Stok Employee</i>
                        <input type="text" class="form-control" placeholder="No Telepon dengan 62">
                      </div>
                      <div class="col-md-2" style="margin-top:18px">
                        <button type="submit" class="btn btn-info btn-block">Get</button>
                      </div>
                    </div>
                    <?= form_close(); ?>
                  </div>

               </div>
               <hr>
            </div>
         </div>
      </div>
   </div>
</section>

<script>
setTimeout(function() {
    $('#mydiv').fadeOut(5000);
}, 3000); 
</script>