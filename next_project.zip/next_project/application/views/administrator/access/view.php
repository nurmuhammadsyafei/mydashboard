
<script src="<?= base_url('assets/bower_components/jquery/dist/jquery.min.js')?>"></script>

<script>
    function coba(value)
    {
    var halaman= "<?= base_url('administrator/access/view_detail/') ?>"+value;
        $("#kupret").load(halaman);
        $(".loadan").show(400);
        $("#new").hide(400);
    }

    function tambah(value)
    {   
        var hal = "<?= base_url('administrator/access/new_grup') ?>";
        $("#new").load(hal);
        $("#new").toggle(400);
        $(".loadan").hide(400);
    }

    $(document).ready(function(){
        $("#hide").click(function(){
            $(".loadan").toggle(400);
        });
    });
</script> 



<!-- STAR MODAL NEW -->
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?= base_url('administrator/grup/add') ?>" method="POST">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">New Grup</h4>
            </div>
            <div class="modal-body">
                <div class="row"><div class="col-md-12"><i>Nama Grup</i>
                    <input type="text"name="_nama"class="form-control">
                </div></div>
                <div class="row"><div class="col-md-12"><i>Deskripsi</i>
                    <input type="text"name="_desc"class="form-control">
                </div></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- END MODAL NEW -->

<div class="row">
    <div class="col-md-6" >
        <div class="box box-success">
            <div class="box-header with-border">
                
                <div class="row">
                    <div class="col-md-4">
                        <h3 class="box-title">Access Group</h3>
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-success" onclick="tambah()">New Grup</button>
                    </div>
                </div>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse">
                        <i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove">
                        <i class="fa fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="box-body no-padding">
                <div class="col-md-12 col-sm-9">
                    <table id="" class=" table table-bordered table-striped"><!--Tambah class example2 kalo mau ada filter-->
                        <thead>
                        <tr>
                            <th>Nama Grup</th>
                            <th>Deskripsi Grup</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $no=1; foreach($access as $a ){?>
                            <tr>
                                <td><?= $a['nama_grup']?></td>
                                <td><?= $a['desc_grup']?></td>
                                <td>
                                <div class="btn-group float-right">
                                    <a href="#"
                                        class="btn btn-info" 
                                        Onclick="coba(<?= $a['id_grup']?>)"
                                    >
                                    <i class="fa fa-pencil"></i></a>
                                    <a href="<?= base_url('administrator/access/delete_grup/').$a['id_grup'] ?>"
                                        class="btn btn-danger" 
                                        onclick="return confirm('Hapus Akun Ini ?');">
                                    <i class="fa fa-close"></i></a>
                                </div>
                                </td>
                            </tr>
                        <?php } ?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-5 loadan"id="kupret"style="display: none">
    </div>
    <div class="col-md-5 "id="new"style="display: none">
    </div>
    <div class="col-md-1 pl-5 loadan"id="kupret"style="display: none">
        <button type="button" class="btn btn-danger" id="hide">Close</button>
    </div>
</div>


<script>
setTimeout(function() {
    $('#mydiv').fadeOut(5000);
}, 3000); 
</script>
