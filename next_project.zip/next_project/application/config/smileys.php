<?php

ket 1 ="PENGINPUTAN";
ket 2 && (UserGroupID =9|| UserGroupID =10|) ="RSM";			
ket 2 && (UserGroupID =18|| UserGroupID =24||UserGroupID =30 || UserGroupID =36) ="TSM";									
ket 4="RSH";		
ket 5="Approve RSM";
ket 5="Approve TSM";
ket 6="Approve SGV";
ket 7="DECLINE";
ket 8="HOLD HIRING - DATA TIDAK SESUAI";
ket 9="HOLD HIRING - DOKUMEN TIDAK lENGKAP";
ket 10="HOLD HIRING - DOKUMEN TIDAK SESUAI";
ket 11="TERMINATE RED";
ket 12="TERMINATE YELLOW";
ket 13="RESIGN";
ket 14="Restruck";


