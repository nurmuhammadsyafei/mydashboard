<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Welcome_fe extends MY_Controller{
	 
    public function index()
    {
        $this->fe_page('fe/index');
    }
	
}



