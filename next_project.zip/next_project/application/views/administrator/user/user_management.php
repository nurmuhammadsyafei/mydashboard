<style>#image-preview{display:none;width : 97px;height : 97px;}</style>

<div class="row">
    <div class="col-md-12">
        <div class="box box-success">
            <div class="box-header with-border">
                
                <div class="row">
                    <div class="col-md-4">
                        <h3 class="box-title">Auth User</h3>
                    </div>
                    <div class="col-md-6" id="mydiv">
                        <?= $this->session->flashdata('message'); ?>
                    </div>
                </div>
                <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                </div>
            </div>
            <div class="box-body no-padding">
                <div class="row">
                <div class="col-md-12 col-sm-9">
                        <table class="example2 table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Level</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($auth as $a ){?>
                                <tr>
                                    <td><?= $a['auth_username']?></td>
                                    <td><?= $a['auth_email']?></td>
                                    <td><?= $a['nama_grup']?></td>
                                    <td><?= $a['status_name']?></td>
                                    <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-info<?= $a['auth_id']?>"><i class="fa fa-edit"></i></button>
                                        <!-- <button type="button" class="btn btn-danger"></button> -->
                                        <a href="<?= base_url('administrator/user_management/get_delete/').$a['auth_id'] ?>"class="btn btn-danger" onclick="return confirm('Hapus Akun Ini ?');"><i class="fa fa-close"></i></a>
                                    </div>
                                    </td>
                                </tr>
                                <!-- MODAL -->
                                <div class="modal  fade" id="modal-info<?= $a['auth_id']?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                                <h3 class="text-center modal-title">Edit Profil</h3>
                                            <?php $qry = $this->db->get_where('auth_user',['auth_id'=>$a['auth_id']])->row_array();?>

                                            </div>
                                            <div class="modal-body">
                                            <form action="<?= base_url('administrator/user_management/go_edit_2') ?>" method="POST" enctype="multipart/form-data">
                                                <div class="">
                                                
                                                    <ul class="list-group list-group-unbordered">
                                                    <li class="list-group-item ">
                                                        <b>Username</b> 
                                                        <input name="_id" type="hidden" value="<?= $qry['auth_id']?>">
                                                        <input name="_username" class="form-control input-sm" type="text" value="<?= $qry['auth_username']?>">
                                                    </li>
                                                    <li class="list-group-item ">
                                                        <b>Email</b>
                                                        <input name="_email" class="form-control input-sm" type="email" value="<?= $qry['auth_email']?>">
                                                    </li>
                                                    <li class="list-group-item ">
                                                        <b>Level</b> 
                                                        <?php $level = $this->db->query("SELECT * FROM menu_grup")->result_array();?>
                                                        <select class="form-control" name="_level">
                                                        <option value="">Pilih level</option>
                                                        <?php foreach($level as $a ){
                                                            $c=$a['nama_grup'];
                                                            $id=$a['id_grup'];
                                                            echo "<option value='$id'";
                                                            echo $qry['auth_level']==$id?'selected="selected"':'';
                                                            echo ">$c</option>"; 
                                                        } ?>
                                                        </select>
                                                    </li>
                                                    </li>
                                                    <li class="list-group-item ">
                                                        <b>Status</b>
                                                        <?php $stt = $this->db->query("SELECT * FROM status")->result_array();?>
                                                        <select class="form-control" name="_status">
                                                            <option value="">Pilih Status</option>
                                                            <?php foreach($stt as $a ){
                                                            $c=$a['status_name'];
                                                            $id=$a['id'];
                                                            echo "<option value='$id'";
                                                            echo $qry['auth_is_active']==$id?'selected="selected"':'';
                                                            echo ">$c</option>"; 
                                                        } ?>
                                                        </select>
                                                    </li>
                                                    <li class="list-group-item ">
                                                    <b>Foto</b>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <input type="hidden" name="_fotolama" value="<?=$qry['auth_image']?>">
                                                            <input name="_foto" class="form-control" type="file" id="image-source" onchange="previewImage();" >
                                                        </div>
                                                        <div class="col-md-3">
                                                            <img class="profile-user-img " src="<?= base_url('image/').$qry['auth_image'] ?>" alt="User profile picture">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <img id="image-preview" alt="image preview" />
                                                        </div>
                                                    </div>
                                                    </li>
                                                    </ul>
                                                   
                                            </div>
                                            <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary btn-block"><b>Update</b></button>
                                                </form>
                                            </div>
                                        </div>
                                    <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- END MODAL -->
                            <?php } ?> 
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Rendering engine</th>
                                <th>Browser</th>
                                <th>Platform(s)</th>
                                <th>Engine version</th>
                                <th>CSS grade</th>
                            </tr>
                            </tfoot>
                        </table>
                         <div class="btn-group">
                            <a href="<?= base_url('administrator/user_management/add')?>" class="btn btn-info">Create New</a>
                            <button type="button" class="btn btn-warning">Right</button>
                            <button type="button" class="btn btn-success">Right</button>
                        </div>
                <div class="col-md-3 col-sm-4">
                </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
setTimeout(function() {
    $('#mydiv').fadeOut(5000);
}, 3000); 
</script>
<script>
function previewImage() {
    document.getElementById("image-preview").style.display = "block";
    var oFReader = new FileReader();
     oFReader.readAsDataURL(document.getElementById("image-source").files[0]);

    oFReader.onload = function(oFREvent) {
      document.getElementById("image-preview").src = oFREvent.target.result;
    };
  };
</script>