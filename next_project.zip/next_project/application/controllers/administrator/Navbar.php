<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Navbar extends MY_Controller		
{
	 
	public function __construct()
	{
		parent::__construct();
		$this->load->library('custom_library');
		if($this->session->userdata('status') != "login"){
			$this->session->set_flashdata('message','<div class="alert alert-danger text-center" role="alert">Anda Harus Login!</div>');
			redirect(base_url('administrator/welcome'));
		}
	}

	public function index()
	{
        $data['menu']=$this->db->get('fe_navbar')->result_array();
        
		$this->page('administrator/navbar/list',$data);
    }
    
	public function add()
	{
		$this->db->select_max('sort');
		$max=$this->db->get('fe_navbar')->row_array();
		$data=[
			'nama_menu'=>$this->input->post('_nama',true),
			'link_menu'=>$this->input->post('_link',true),
			'icon_menu'=>$this->input->post('_icon',true),
			'sort'	   =>$max['sort']+1
		];
		$this->db->insert('fe_navbar',$data);
		redirect(base_url('administrator/navbar'));
	}

	public function get_edit()
	{
		$data=[
			'nama_menu'=>$this->input->post('_nama',true),
			'link_menu'=>$this->input->post('_link',true),
			'icon_menu'=>$this->input->post('_icon',true),
			'sort'	   =>$this->input->post('_sort',true)
		];
		
		$this->db->where('id_menu',$this->input->post('_id',true));
		$this->db->update('fe_navbar',$data);
		redirect(base_url('administrator/navbar'));
	}
	
	public function tes()
	{
		// $data=$this->db->query("SELECT MAX('sort') FROM fe_navbar")->result_array();

		$this->db->select_max('sort');
		$data=$this->db->get('fe_navbar')->row_array();
		var_dump($data['sort']);
	}
    
}



