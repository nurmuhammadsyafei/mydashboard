<!DOCTYPE html>
<html lang="en">
  <head>
    <title>FMLArea</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700|Playfair+Display:400,700,900" rel="stylesheet">
  
    <link rel="stylesheet" href="<?= base_url('assets/fe/fonts/icomoon/style.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/css/magnific-popup.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/css/jquery-ui.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/css/owl.carousel.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/css/owl.theme.default.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/css/bootstrap-datepicker.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/fonts/flaticon/font/flaticon.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/fe/css/aos.css') ?>">

    <link rel="stylesheet" href="<?= base_url('assets/fe/css/style.css') ?>">
  </head>
  <body>
  
  <header class="site-navbar" role="banner">
    <div class="container-fluid">
        <div class="row align-items-center">
        
        <div class="col-12 search-form-wrap js-search-form">
            <form method="get" action="#">
            <input type="text" id="s" class="form-control" placeholder="Search...">
            <button class="search-btn" type="submit"><span class="icon-search"></span></button>
            </form>
        </div>

        <div class="col-4 site-logo">
            <a href="index.html" class="text-black h2 mb-0">FMListrik_3</a>
        </div>

        <div class="col-8 text-right">
            <nav class="site-navigation" role="navigation">
            <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block mb-0">
            <?php 
            $this->db->order_by('sort','ASC');
            $data=$this->db->get_where('fe_navbar')->result_array(); ?>
                <?php foreach($data as $dt){ ?>
                <li><a href="<?= base_url().$dt['link_menu'] ?>"><?= $dt['nama_menu']?></a></li>
                <?php }?>
                <!-- <li class="d-none d-lg-inline-block"><a href="#" class="js-search-toggle"><span class="icon-search"></span></a></li> -->
            </ul>
            </nav>
            <a href="#" class="site-menu-toggle js-menu-toggle text-black d-inline-block d-lg-none"><span class="icon-menu h3"></span></a></div>
        </div>

    </div>
    </header>
</div>